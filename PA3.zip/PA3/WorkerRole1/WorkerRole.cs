using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Diagnostics;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using Microsoft.WindowsAzure.Storage.Queue;
using System.Configuration;

namespace WorkerRole1
{
    public class WorkerRole : RoleEntryPoint
    {
        private readonly CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
        private readonly ManualResetEvent runCompleteEvent = new ManualResetEvent(false);

        public CloudQueue initializeStartAndStopQ()
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(
                ConfigurationManager.AppSettings["StorageConnectionString"]);
            CloudQueueClient qClient = storageAccount.CreateCloudQueueClient();
            CloudQueue q = qClient.GetQueueReference("startandstop");
            q.CreateIfNotExists();
            return q;
        }

        public CloudQueue initializeURLQ()
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(
                ConfigurationManager.AppSettings["StorageConnectionString"]);
            CloudQueueClient qClient = storageAccount.CreateCloudQueueClient();
            CloudQueue q = qClient.GetQueueReference("urls");
            q.CreateIfNotExists();
            return q;
        }

        public CloudTable initializeTable()
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(
                ConfigurationManager.AppSettings["StorageConnectionString"]);
            CloudTableClient tableClient = storageAccount.CreateCloudTableClient();
            CloudTable table = tableClient.GetTableReference("urltable");
            table.CreateIfNotExists();
            return table;
        }

        private String EncodeURL(String url)
        {
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(url);
            String encodedString = System.Convert.ToBase64String(bytes);
            return encodedString.Replace('/', '_');
        }

        public CloudQueue initializeURLTitleDateQ()
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(
                ConfigurationManager.AppSettings["StorageConnectionString"]);
            CloudQueueClient qClient = storageAccount.CreateCloudQueueClient();
            CloudQueue q = qClient.GetQueueReference("rawdata");
            q.CreateIfNotExists();
            return q;
        }

        public override void Run()
        {
            Trace.TraceInformation("WorkerRole1 is running");
            while (true)
            {
                // Check if start and stop queue has a message
                Thread.Sleep(50);
                CloudQueue q = initializeStartAndStopQ();
                CloudQueueMessage message = q.GetMessage();
                // Start crawling
                if (message != null)
                {
                    // Read file from queue robots.txt
                    CloudQueue URLQ = initializeURLQ();
                    CloudQueueMessage urlsMessage = URLQ.GetMessage();
                    int count = 0;
                    // Split txt file into lines
                    if (urlsMessage != null) { 
                        String urls = urlsMessage.AsString;
                        Char[] delimeterArray = { '\n' };
                        String[] robotsArray = urls.Split(delimeterArray);

                        // Write to queue
                        List<String> siteMaps = new List<String>();
                        List<String> disallows = new List<String>();
                        List<String> siteMapsWithAnotherLevel = new List<String>();
                        // Loop through robots.txt
                        foreach (String line in robotsArray)
                        {
                            if (line.StartsWith("Sitemap:"))
                            {
                                // String of link is after "Sitemap:"
                                String siteMap = line.Substring(9);
                                // Sitemap to more sitemaps. another level
                                if (line.EndsWith("index.xml"))
                                {
                                    siteMapsWithAnotherLevel.Add(siteMap);

                                    // Sitemap to html pages!
                                }
                                else if (line.Equals("Sitemap: http://bleacherreport.com/sitemap/nba.xml") ||
                                         line.StartsWith("Sitemap: http://www.cnn.com"))
                                {
                                    siteMaps.Add(siteMap);
                                }
                            }
                            else if (line.StartsWith("Disallow:"))
                            {
                                // String of disallow is after "Disallow: "
                                String disallow = line.Substring(10);
                                disallows.Add(disallow);
                            }
                        }

                        String date = "";
                        // Titles 
                        // Loop through xml "http://bleacherreport.com/sitemap/nba.xml"
                        //List<String> indexHTMLs = new List<String>();
                        //URLQ.Clear();
                        CloudQueue URLTitleDateQ = initializeURLTitleDateQ();
                        HashSet<String> indexHTMLs = new HashSet<String>();
                        foreach (String siteMapXML in siteMaps)
                        {
                            // Go to the sitemap url
                            String contentsOfSiteMapXMLTxtFile = new WebClient().DownloadString(siteMapXML);
                            // Split it by lines.
                            //contentsOfSiteMapXMLTxtFile = contentsOfSiteMapXMLTxtFile.Trim();
                            String[] siteMapXMLArray = contentsOfSiteMapXMLTxtFile.Split(delimeterArray);

                            
                            // right now a url tag has not been found in the sitemap
                            Boolean newURLOrEOF = false;
                            // only changes when new url tag has been found
                            String URLDate = "";
                            foreach (String XMLLine in siteMapXMLArray)
                            {
                                String XMLLineTrimmed = XMLLine.Trim();
                                String locStart = "<loc>";
                                String locEnd = "</loc>";
                                int locStartIndex = XMLLineTrimmed.IndexOf(locStart);
                                int locEndIndex = XMLLineTrimmed.IndexOf(locEnd);
                                int urlStart = locStartIndex + locStart.Length;
                                // dates are in this file too, but titles are in the actual html
                                String newsPubStart = "<news:publication_date>";
                                String newsPubEnd = "</news:publication_date>";
                                int newsPubStartIndex = XMLLineTrimmed.IndexOf(newsPubStart);
                                int newsPubEndIndex = XMLLineTrimmed.IndexOf(newsPubEnd);
                                int newsStart = newsPubStartIndex + newsPubStart.Length;
                                if (locStartIndex != -1 && locEndIndex != -1)
                                {
                                    String locURL = XMLLineTrimmed.Substring(urlStart, locEndIndex - urlStart);
                                    URLDate = locURL;
                                    if (newsPubStartIndex != -1 && newsPubEndIndex != -1)
                                    {
                                        String newsPubDate = XMLLineTrimmed.Substring(newsStart, newsPubEndIndex - newsStart);
                                        URLDate += " " + newsPubDate;
                                    }
                                    // found the url and date add to url queue, they have not been crawled yet!
                                    //URLQ.AddMessage(new CloudQueueMessage(URLDate));
                                    URLTitleDateQ.AddMessage(new CloudQueueMessage(URLDate));
                                    newURLOrEOF = true;
                                }

                                // A new url tag has been found or end of file because </urlset> tag was found.
                                // need to add this to has set.
                                // Add to hash set even if the url already exists because it won't allow duplicates   
                                if (newURLOrEOF && !URLDate.Equals(""))
                                {
                                    indexHTMLs.Add(URLDate);
                                    URLDate = "";
                                }
                            }

                            CloudTable table = initializeTable();
                            Entity e = new Entity();
                            // list for 10 urls at a time
                            List<String> tenURLS = new List<String>();
                            int urlCount = 0;
                            // get url from url queue
                            while (true)
                            {
                                CloudQueueMessage urlMsg = URLTitleDateQ.GetMessage();

                                if (urlMsg == null)
                                {
                                    break;
                                }
                                else
                                {
                                    URLTitleDateQ.DeleteMessageAsync(urlMsg);
                                    Char[] whiteSpaceDelimterArray = { ' ' };
                                    // parse the cloudqueuemessage
                                    String url = urlMsg.AsString;
                                    String dTime = "";
                                    if (urlMsg.AsString.Contains(" "))
                                    {
                                        String[] urlDateArray = urlMsg.AsString.Split(whiteSpaceDelimterArray);
                                        url = urlDateArray[0];
                                        dTime = urlDateArray[1];
                                    }
                                    Boolean okayToCrawl = true;
                                    foreach (String disallow in disallows)
                                    {
                                        if (url.Contains(disallow))
                                        {
                                            okayToCrawl = false;
                                            //break;
                                        }
                                    }

                                    if (okayToCrawl)
                                    {
                                        String pKey = "";
                                        // Get the html code of the url
                                        try { 
                                        //Uri myUri;
                                        // Checks if url is valid.
                                        //if (Uri.TryCreate(url, UriKind.RelativeOrAbsolute, out myUri))
                                        //{
                                            String htmlCode = new WebClient().DownloadString(url);
                                            // Split it by lines
                                            //String[] htmlCodeArray = htmlCode.Split(delimeterArray);
                                            String titleStart = "<title>";
                                            int titleStartIndex = htmlCode.IndexOf(titleStart);
                                            int titleEndIndex = htmlCode.IndexOf("</title>");
                                            int substringStartIndex = titleStartIndex + titleStart.Length;
                                            String title = htmlCode.Substring(substringStartIndex, titleEndIndex - substringStartIndex);

                                            // Add url, title, and date as one string into Azure table.

                                            // add url
                                            String URLTitleDate = url;
                                            // add space and title
                                            URLTitleDate += "<title>" + title;
                                            // if available, add space and date
                                            if (!dTime.Equals(","))
                                            {
                                                URLTitleDate += "<dateTime>" + dTime;
                                            }
                                            // Add the URLTitleDate to Azure table
                                            
                                            if (URLTitleDate.StartsWith("http://www.cnn.com"))
                                            {
                                                pKey = "CNN";
                                            }
                                            else if (URLTitleDate.StartsWith("http://bleacherreport.com"))
                                            {
                                                pKey = "BleacherReport";
                                            }
                                            e = new Entity(pKey, EncodeURL(URLTitleDate));
                                            // add the url title and date to the list
                                            //tenURLS.Add(URLTitleDate);
                                            //urlCount++;
                                            // Insert into table and 
                                            // Reset the list when there are ten elements 
                                            /*if (urlCount == 10)
                                            {
                                                String listString = String.Join("<URLTitleDate>", tenURLS.ToArray());
                                                e = new Entity(pKey, EncodeURL(listString));
                                                TableOperation insert = TableOperation.InsertOrReplace(e);
                                                table.Execute(insert);
                                                tenURLS = new List<String>();
                                                urlCount = 0;
                                            }*/
                                        }
                                        catch
                                        {
                                            pKey = "error";
                                            e = new Entity(pKey, EncodeURL(url));
                                        }

                                        TableOperation insert = TableOperation.InsertOrReplace(e);
                                        table.Execute(insert);
                                    }
                                }
                            }
                        }
                    }
                    // Stop the StartAndStopQueue. 
                    // Worker doesn't need to keep going until user hits start again.
                    q.Clear();

                }

            }
        }

        public override bool OnStart()
        {
            // Set the maximum number of concurrent connections
            ServicePointManager.DefaultConnectionLimit = 12;

            // For information on handling configuration changes
            // see the MSDN topic at http://go.microsoft.com/fwlink/?LinkId=166357.

            bool result = base.OnStart();

            Trace.TraceInformation("WorkerRole1 has been started");

            return result;
        }

        public override void OnStop()
        {
            Trace.TraceInformation("WorkerRole1 is stopping");

            this.cancellationTokenSource.Cancel();
            this.runCompleteEvent.WaitOne();

            base.OnStop();

            Trace.TraceInformation("WorkerRole1 has stopped");
        }

        private async Task RunAsync(CancellationToken cancellationToken)
        {
            // TODO: Replace the following with your own logic.
            while (!cancellationToken.IsCancellationRequested)
            {
                Trace.TraceInformation("Working");
                await Task.Delay(1000);
            }
        }
    }
}
