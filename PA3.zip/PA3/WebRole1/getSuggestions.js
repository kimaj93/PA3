﻿function clearEverything() {
    $.ajax({
        type: "POST",
        url: "WebService1.asmx/clearEverything",
        data: {},
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $("#clearMessage").html(msg.d);
        },
        error: function (msg) {
            alert(JSON.stringify(msg));
        }
    });
};

function startCrawling() {
    $.ajax({
        type: "POST",
        url: "WebService1.asmx/startCrawling",
        data: {},
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $("#crawlMessage").html(msg.d);
        },
        error: function (msg) {
            alert(JSON.stringify(msg));
        }
    });
};

function getQSize() {
    $.ajax({
        type: "POST",
        url: "WebService1.asmx/getQSize",
        data: {},
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $("#qMessage").html(msg.d);
        },
        error: function (msg) {
            alert(JSON.stringify(msg));
        }
    });
};

function getURLsAndErrors() {
    $.ajax({
        type: "POST",
        url: "WebService1.asmx/getURLsAndErrors",
        data: {},
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $("#URLAndErrorMessage").html(msg.d);
        },
        error: function (msg) {
            alert(JSON.stringify(msg));
        }
    });
};

