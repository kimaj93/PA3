﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;

namespace WebRole1
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public String clearEverything()
        {
            clearQ();
            deleteTable();
            return "Cleared everything (index/table, queue/pipeline, stopped all worker roles)";            
        }

        [WebMethod]
        public void clearQ()
        {
            initializeStartAndStopQ().Clear();
            initializeURLQ().Clear();
            initializeURLTitleDateQ().Clear();
        }

        public CloudQueue initializeURLQ()
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(
                ConfigurationManager.AppSettings["StorageConnectionString"]);
            CloudQueueClient qClient = storageAccount.CreateCloudQueueClient();
            CloudQueue q = qClient.GetQueueReference("urls");
            q.CreateIfNotExists();
            return q;
        }

        [WebMethod]
        public void deleteTable()
        {
            CloudTable table = initializeTable();
            table.DeleteIfExists();
        }

        public CloudTable initializeTable()
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(
                ConfigurationManager.AppSettings["StorageConnectionString"]);
            CloudTableClient tableClient = storageAccount.CreateCloudTableClient();
            CloudTable table = tableClient.GetTableReference("urltable");
            table.CreateIfNotExists();
            return table;
        }

        public CloudQueue initializeStartAndStopQ()
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(
                ConfigurationManager.AppSettings["StorageConnectionString"]);
            CloudQueueClient qClient = storageAccount.CreateCloudQueueClient();
            CloudQueue q = qClient.GetQueueReference("startandstop");
            q.CreateIfNotExists();
            return q;
        }
        
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public int getQSize()
        {
            CloudQueue q = initializeURLTitleDateQ();
            q.FetchAttributes();
            int qCnt = (int) q.ApproximateMessageCount;
            return qCnt;
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public String startCrawling()
        {
            // Start worker role
            CloudQueue startQ = initializeStartAndStopQ();
            startQ.AddMessage(new CloudQueueMessage("Start"));

            // Put robots txt into url queue.
            CloudQueue urlQ = initializeURLQ();
            String contentsOfCNNRobots = new WebClient().DownloadString("http://cnn.com/robots.txt");
            String contentsOfBleacherRobots = new WebClient().DownloadString("http://bleacherreport.com/robots.txt");
            String m = contentsOfBleacherRobots + contentsOfCNNRobots;
            urlQ.AddMessage(new CloudQueueMessage(m));
            if (urlQ.PeekMessage() == null)
            {
                return "nothing in the q";
            }
            return "Crawling these robot files: \n" + urlQ.PeekMessage().AsString;
        }

        private String DecodeURL(String encodedURL)
        {
            String base64String = encodedURL.Replace('_', '/');
            byte[] bytes = System.Convert.FromBase64String(base64String);
            return System.Text.Encoding.UTF8.GetString(bytes);
        }

        public CloudQueue initializeURLTitleDateQ()
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(
                ConfigurationManager.AppSettings["StorageConnectionString"]);
            CloudQueueClient qClient = storageAccount.CreateCloudQueueClient();
            CloudQueue q = qClient.GetQueueReference("rawdata");
            q.CreateIfNotExists();
            return q;
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public String GetURLsAndErrors()
        {
            // Stop worker role
            CloudQueue stopQ = initializeStartAndStopQ();
            stopQ.Clear();

            // Get table
            CloudTable table = initializeTable();
            TableQuery<Entity> rangeQuery = new TableQuery<Entity>().
                Where(TableQuery.CombineFilters(
                    TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, "CNN"),
                    TableOperators.Or,
                    TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, "BleacherReport"))
                );
            List<String> b = new List<String>();
            List<String> c = new List<String>();
            List<String> el = new List<String>();
            int count = 0;
            foreach (Entity e in table.ExecuteQuery(rangeQuery))
            {
                count++;
                String urltitledate = DecodeURL(e.RowKey);
                if (urltitledate.StartsWith("http://bleacherreport.com")) {
                    b.Add(urltitledate);
                } else if (urltitledate.StartsWith("http://www.cnn.com")) {
                    c.Add(urltitledate);
                }
                else if (e.RowKey.Equals("error"))
                {
                    el.Add(urltitledate);
                }
            }
           
            String bleachers = String.Join("\n", b.ToArray());
            String cnns = String.Join("\n", c.ToArray());
            String errors = String.Join("\n", el.ToArray());
            return "Total number of urls: " + count + "\nAll BleacherReport titles" + bleachers +
                "\nAll CNN titles: " + cnns + "\nAll URLs with errors: " + errors;
        }
    }
}
